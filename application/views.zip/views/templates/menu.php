<?php

if (!$this->session->userdata('logged_in')) {
    redirect(base_url());
    // Do your code here
}

?>
<section>
    <?php if ($this->session->flashdata('success')): ?>
        <div class="alert alert-success">
            <a href="#" class="close" data-dismiss="alert">&times;</a>
            <strong><?php echo $this->session->flashdata('success'); ?></strong>
        </div>
    <?php elseif ($this->session->flashdata('error')): ?>
        <div class="alert alert-warning">
            <a href="#" class="close" data-dismiss="alert">&times;</a>
            <strong><?php echo $this->session->flashdata('error'); ?></strong>
        </div>
    <?php endif; ?>
    <!-- Left Sidebar -->
    <aside id="leftsidebar" class="sidebar">
        <!-- User Info -->
        <div class="user-info">
            <div class="image">
                <img src="<?php echo base_url() . "assets/images/"; ?><?php echo $this->session->userdata('profile_pic'); ?>" width="48" height="48" alt="User"/>
            </div>
            <div class="info-container">
                <div class="name" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><?php echo $this->session->userdata('name'); ?></div>
                <div class="email"><?php echo $this->session->userdata('email'); ?></div>
                <div class="btn-group user-helper-dropdown">
                    <i class="material-icons" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">keyboard_arrow_down</i>
                    <ul class="dropdown-menu pull-right">
                        <li>
                            <a href="<?php echo base_url(); ?>users/profile?id=<?php echo $this->session->userdata('user_id'); ?>"><i class="material-icons">person</i>Profile</a>
                        </li>
                        <li role="separator" class="divider"></li>
                        <li><a href="<?php echo base_url(); ?>login/logout"><i class="material-icons">input</i>Sign Out</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- #User Info -->
        <!-- Menu -->
        <div class="menu">
            <ul class="list">
                <li class="header">MAIN NAVIGATION</li>
                <li id="dashboard">
                    <a href="<?php echo base_url(); ?>"> <i class="material-icons">home</i> <span>Dashboard</span> </a>
                </li>
             
                <li id="Daily_quiz">
                    <a href="<?php echo base_url() . "Daily_quiz"; ?>"> <i class="material-icons">contact_mail</i>
                        <span>Daily Quize</span> </a>
                </li>

                <li id="Gatavarshi_prashna_patrika_main">
                    <a href="javascript:void(0);" class="menu-toggle"> <i class="material-icons">assignment</i>
                        <span>Gatavarshi Prashna Patrika</span> </a>
                    <ul class="ml-menu">
                        <li id="Gatavarshi_prashna_patrika">
                            <a href="<?php echo base_url() . "Gatavarshi_prashna_patrika"; ?>">
                                <i class="material-icons">people</i> <span>Gatavarshi prashna patrika</span> </a>
                        </li>
                        <li id="Gatavarshi_prashna_patrika_year">
                            <a href="<?php echo base_url() . "Gatavarshichya_prashna_patrika_year"; ?>">
                                <i class="material-icons">people</i> <span>Gatavarshi prashna patrika year</span> </a>
                        </li>
                        <li id="Gatavarshichya_prashna_patrika_live_test">
                            <a href="<?php echo base_url() . "Gatavarshichya_prashna_patrika_live_test"; ?>">
                                <i class="material-icons">people</i>
                                <span>Gatavarshichya Prashna Patrika Exam (Live Test)</span> </a>
                       <!-- <li id="Gatavarshichya_prashna_patrika_year_title">
                            <a href="<?php echo base_url() . "Gatavarshichya_prashna_patrika_year_title"; ?>">
                                <i class="material-icons">people</i>
                                <span>Gatavarshichya Prashna Patrika Exam (Live Test)</span> </a>
                        </li>
                        <li id="Gatavarshichya_prashna_patrika_live_test">
                            <a href="<?php echo base_url() . "Gatavarshichya_prashna_patrika_live_test"; ?>">
                                <i class="material-icons">people</i>
                                <span>Gatavarshichya prashna patrika live test</span> </a>
                        </li>-->
                      
                    </ul>
                </li>

                <li id="Gatavarshiche_prashna_main">
                    <a href="javascript:void(0);" class="menu-toggle"> <i class="material-icons">assignment</i>
                        <span>Gatavarshiche Prashna</span> </a>
                    <ul class="ml-menu">
                        <li id="Gatavarshiche_prashna_subjects">
                            <a href="<?php echo base_url() . "Gatavarshiche_prashna_patrika_subjects"; ?>">
                                <i class="material-icons">people</i> <span>Gatavarshiche Prashna Subjects</span> </a>
                        </li>
                        <li id="Gatavarshichya_prashna_patrika_practice_test">
                            <a href="<?php echo base_url() . "Gatavarshichya_prashna_patrika_practice_test"; ?>">
                                <i class="material-icons">people</i> <span>Gatavarshiche Prashna (Practice Test)</span> </a>
                        </li>
                        

                    </ul>
                </li>
             

                <li id="Sarav_prashnasanch_main">
                    <a href="javascript:void(0);" class="menu-toggle"> <i class="material-icons">assignment</i>
                        <span>Sarav Prashnasanch</span> </a>
                    <ul class="ml-menu">
                        <li id="Sarav_prashnasanch_subjects">
                            <a href="<?php echo base_url() . "Sarav_prashnasanch_subjects"; ?>">
                                <i class="material-icons">people</i> <span>Sarav Prashnasanch Subjects</span> </a>
                        </li>
                        <li id="Sarav_prasnasanch">
                            <a href="<?php echo base_url() . "Sarav_prasnasanch"; ?>">
                                <i class="material-icons">people</i> <span>Sarav Prashnasanch</span> </a>
                        </li>
                    </ul>
                </li>
                
                <li id="Test_series_main">
                    <a href="javascript:void(0);" class="menu-toggle"> <i class="material-icons">assignment</i>
                        <span>Test Series</span> </a>
                    <ul class="ml-menu">
                        <li id="Test_series">
                            <a href="<?php echo base_url() . "Test_series"; ?>"> <i class="material-icons">people</i>
                                <span>Test Series</span> </a>
                        </li>
                        <li id="Test_series_exam">
                            <a href="<?php echo base_url() . "Test_series_exam"; ?>">
                                <i class="material-icons">people</i> <span>Test Series Exam</span> </a>
                        </li>
                    </ul>
                </li>
                
                
                <li id="Pariksha_paddhati_main">
                    <a href="<?php echo base_url() . "Pariksha_paddhati_abhyaskram"; ?>"> <i class="material-icons">people</i>
                        <span>Pariksha Paddhati Abhyaskram</span> </a>
                </li>
                
                <li id="posts">
                    <a href="<?php echo base_url() . "current_affairs"; ?>"> <i class="material-icons">people</i>
                        <span>Current Affairs</span> </a>
                </li>


                <li id="Masike">
                    <a href="javascript:void(0);" class="menu-toggle"> <i class="material-icons">assignment</i>
                        <span>Masike</span> </a>
                    <ul class="ml-menu">
                        <li id="Masike_category">
                            <a href="<?php echo base_url() . "Masike/category"; ?>">
                                <i class="material-icons">people</i> <span>Masike Category</span> </a>
                        </li>
                        <li id="Masike_masike">
                            <a href="<?php echo base_url() . "Masike"; ?>">
                                <i class="material-icons">people</i> <span>Masike</span> </a>
                        </li>
                    </ul>
                </li>
                
              
                
                <li id="Abhyas_sahitya_category_main">
                    <a href="javascript:void(0);" class="menu-toggle"> <i class="material-icons">assignment</i>
                        <span>Abhyas Sahitya</span> </a>
                    <ul class="ml-menu">
                        <li id="Abhyas_sahitya_category">
                            <a href="<?php echo base_url() . "Abhyas_sahitya_category"; ?>">
                                <i class="material-icons">people</i> <span>Category</span> </a>
                        </li>
                   
                        <li id="Abhyas_sahitya">
                            <a href="<?php echo base_url() . "Abhyas_sahitya"; ?>"> <i class="material-icons">people</i>
                                <span>Abhyas Sahitya</span> </a>
                        </li>
                    </ul>
                </li>

                <li id="JobAlert">
                    <a href="<?php echo base_url() . "JobAlert"; ?>"> <i class="material-icons">contact_mail</i>
                        <span>Job Alert</span> </a>
                </li>
                
                <li id="Yashogatha">
                    <a href="<?php echo base_url() . "Yashogatha"; ?>"> <i class="material-icons">people</i>
                        <span>Yashogatha</span> </a>
                </li>
                
                <li id="Video">
                    <a href="<?php echo base_url() . "Videos"; ?>"> <i class="material-icons">people</i>
                        <span>Videos</span> </a>
                </li>

                <li id="doubts">
                    <a href="<?php echo base_url() . "Doubts"; ?>"> <i class="material-icons">contact_mail</i>
                        <span>Doubts</span> </a>
                </li>

                <li id="Push_notification">
                    <a href="javascript:void(0);" class="menu-toggle"> <i class="material-icons">assignment</i>
                        <span>Push Notification</span> </a>
                    <ul class="ml-menu">
                        <li id="all">
                            <a href="<?php echo base_url() . "Push_notification/all"; ?>">
                                <i class="material-icons">people</i> <span>Sent to all</span> </a>
                        </li>
                        <li id="group">
                            <a href="<?php echo base_url() . "Push_notification/group"; ?>">
                                <i class="material-icons">people</i> <span>Sent to group</span> </a>
                        </li>
                        <li id="single">
                            <a href="<?php echo base_url() . "Push_notification/single"; ?>">
                                <i class="material-icons">people</i> <span>Sent to user</span> </a>
                        </li>
                    </ul>
                </li>
                <li id="master">
                    <a href="javascript:void(0);" class="menu-toggle"> <i class="material-icons">assignment</i>
                        <span>Master</span> </a>
                    <ul class="ml-menu">
                        <li id="Exam_subject">
                            <a href="<?php echo base_url() . "Exam_subject"; ?>">
                                <i class="material-icons">people</i> <span>Exam Section</span> </a>
                        </li>

                        <li id="All_exam_list">
                            <a href="<?php echo base_url() . "All_exam_list"; ?>"> <i class="material-icons">people</i>
                                <span>Manage Exam</span> </a>
                        </li>

                        <li id="app_users">
                            <a href="<?php echo base_url() . "app_users"; ?>"> <i class="material-icons">people</i>
                                <span>Manage App Users</span> </a>
                        </li>

                        <li id="Banner">
                            <a href="<?php echo base_url() . "Banner"; ?>"> <i class="material-icons">people</i>
                                <span>Banner Image</span> </a>
                        </li>
                    </ul>
                </li>
                
                
               
            </ul>
        </div>
        <!-- #Menu -->
        <!-- Footer -->
        <div class="legal">
            <div class="copyright">
                &copy; 2014 - 2019 <a href="http://codingvisions.com/">Coding Visions Infotetch Pvt. Ltd.</a>.
            </div>
            <div class="version">
                <b>Version: </b> 1.0.6
            </div>
        </div>
        <!-- #Footer -->
    </aside>
    <!-- #END# Left Sidebar -->
</section>
<style type="text/css">
    .modal-body p {
        margin-bottom: 0;
    }

    .bootstrap-select {
        z-index: 99999 !important;
    }

    .bootstrap-select .dropdown-menu {
        z-index: 999999 !important;
    }
</style>
