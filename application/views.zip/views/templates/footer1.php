
    <!-- Jquery Core Js -->
    <script src="<?php echo base_url()."assets/"; ?>plugins/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core Js -->
    <script src="<?php echo base_url()."assets/"; ?>plugins/bootstrap/js/bootstrap.js"></script>

    <!-- Select Plugin Js -->
    <script src="<?php echo base_url()."assets/"; ?>plugins/bootstrap-select/js/bootstrap-select.js"></script>

    <!-- Dropzone Plugin Js -->
    <script src="<?php echo base_url()."assets/"; ?>plugins/dropzone/dropzone.js"></script>

    <!-- Slimscroll Plugin Js -->
    <script src="<?php echo base_url()."assets/"; ?>plugins/jquery-slimscroll/jquery.slimscroll.js"></script>
    <!-- Jquery CountTo Plugin Js -->
    <script src="<?php echo base_url()."assets/"; ?>plugins/jquery-countto/jquery.countTo.js"></script>

    <!-- Multi Select Plugin Js -->
    <script src="<?php echo base_url()."assets/"; ?>plugins/multi-select/js/jquery.multi-select.js"></script>

    <!-- Waves Effect Plugin Js -->
    <script src="<?php echo base_url()."assets/"; ?>plugins/node-waves/waves.js"></script>

    <!-- Ckeditor -->
<!--     <script src="<?php echo base_url()."assets/"; ?>plugins/ckeditor/ckeditor.js"></script> -->
<script src="https://cdn.ckeditor.com/4.16.0/full-all/ckeditor.js"></script>
    
    <!-- SweetAlert Plugin Js -->
    <script src="<?php echo base_url()."assets/"; ?>plugins/sweetalert/sweetalert.min.js"></script>

    <!-- Jquery DataTable Plugin Js -->
    <script src="<?php echo base_url()."assets/"; ?>plugins/jquery-datatable/jquery.dataTables.js"></script>
    <script src="<?php echo base_url()."assets/"; ?>plugins/jquery-datatable/skin/bootstrap/js/dataTables.bootstrap.js"></script>
    <script src="<?php echo base_url()."assets/"; ?>plugins/jquery-datatable/extensions/export/dataTables.buttons.min.js"></script>
    <script src="<?php echo base_url()."assets/"; ?>plugins/jquery-datatable/extensions/export/buttons.flash.min.js"></script>
    <script src="<?php echo base_url()."assets/"; ?>plugins/jquery-datatable/extensions/export/jszip.min.js"></script>
    <script src="<?php echo base_url()."assets/"; ?>plugins/jquery-datatable/extensions/export/pdfmake.min.js"></script>
    <script src="<?php echo base_url()."assets/"; ?>plugins/jquery-datatable/extensions/export/vfs_fonts.js"></script>
    <script src="<?php echo base_url()."assets/"; ?>plugins/jquery-datatable/extensions/export/buttons.html5.min.js"></script>
    <script src="<?php echo base_url()."assets/"; ?>plugins/jquery-datatable/extensions/export/buttons.print.min.js"></script>
        <!-- Jquery Validation Plugin Css -->
    <script src="<?php echo base_url()."assets/"; ?>plugins/jquery-validation/jquery.validate.js"></script>
       <!-- Custom Js -->
       <!-- Bootstrap Material Datetime Picker Plugin Js -->
    <script src="<?php echo base_url()."assets/"; ?>plugins/bootstrap-material-datetimepicker/js/bootstrap-material-datetimepicker.js"></script>

    <!-- Bootstrap Datepicker Plugin Js -->
    <script src="<?php echo base_url()."assets/"; ?>plugins/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
    <script src="<?php echo base_url()."assets/"; ?>js/admin.js"></script>
    <script src="<?php echo base_url()."assets/"; ?>plugins/bootstrap-notify/bootstrap-notify.js"></script>

</body>

</html>
<style type="text/css">
.modal-lg{
    width: 98%;
}
</style>