<?php
/**
 * Web Based Software Activation System
 * Developed By
 * Sagar Maher
 * Coding Visions Infotech Pvt. Ltd.
 * http://codingvisions.com/
 * 31/01/2019
 */
?>
<!-- Modal Dialogs ====================================================================================================================== -->
<!-- Default Size -->
<div class="modal fade" id="edit" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-lg" role="document">
        <form id="add_masike_form" enctype="multipart/form-data" action="<?php echo base_url() ?>Videos/update_data" method="POST">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="defaultModalLabel">Add New Videos</h4>
                </div>
                <div class="modal-body">
                    <!-- Masked Input -->
                    <div class="row clearfix">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="card">
                                <input type="hidden" name="edit_id" id="edit_id">
                                <div class="body">
                                    <div class="demo-masked-input">
                                        <div class="row clearfix">

                                            <div class="col-md-6">
                                                <b>Title</b>
                                                <div class="input-group">
                                                    <span class="input-group-addon">
                                                        <i class="material-icons">person</i>
                                                    </span>
                                                    <div class="form-line">
                                                        <input type="text" name="Title" id="edit_Title"
                                                               class="form-control text" placeholder="Title" required>
                                                    </div>
                                                </div>
                                            </div>
                                             <div class="col-md-6">
                                                <b>Exams :</b>
                                                <div class="input-group">
                                                    <span class="input-group-addon">
                                                        <i class="material-icons">person</i>
                                                    </span>
                                                    <div class="form-line">
                                                      <select class="form-control" id="edit_exams" name="exams[]" multiple="">
                                                        <?php
                                                          $sql="SELECT * FROM exams WHERE status='Active'";
                                                          $check=$this->common_model->executeArray($sql);
                                                          if($check)
                                                          {
                                                            foreach ($check as $value)
                                                            {
                                                              echo '<option value="'.$value->exam_id.'">'.$value->exam_name.'</option>';
                                                            }
                                                          }
                                                        ?>
                                                      </select>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row clearfix">
                                            <div class="col-md-6">
                                                <b>URL </b>
                                                <div class="input-group">
                                                    <span class="input-group-addon">
                                                        <i class="material-icons">person</i>
                                                    </span>
                                                    <div class="form-line">
                                                        <input type="text" name="URL" id="edit_url"
                                                               class="form-control text" placeholder="URL" required>
                                                    </div>
                                                </div>

                                            </div>
                                            <div class="col-md-6">
                                                <b>Duration </b>
                                                <div class="input-group">
                                                    <span class="input-group-addon">
                                                        <i class="material-icons">person</i>
                                                    </span>
                                                    <div class="form-line">
                                                        <input type="text" name="duration" id="edit_duration"
                                                               class="form-control text" placeholder="Duration" required>
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                        <div class="row clearfix">
                                            
                                           <div class="col-md-6">
                                              <p>
                                                  <b>Video Type</b>
                                              </p>
                                              <select class="form-control show-tick" name="video_status" id="edit_video_status" >
                                                  <option value="free">Free</option>
                                                  <option value="paid">paid</option>

                                              </select>

                                          </div>
                                           <div class="col-md-6">
                                              <p>
                                                  <b>Output Type</b>
                                              </p>
                                              <select class="form-control show-tick" name="output_type" id="edit_output_type">
                                                  <option value="youtube">Youtube</option>
                                                  <option value="vimeo">Vimeo</option>
                                                  <option value="exo_player">Exo Player</option>

                                              </select>

                                          </div>




                                           <div class="col-md-6">
                                              <p>
                                                  <b>Status</b>
                                              </p>
                                              <select class="form-control show-tick" name="status" id="edit_status" >
                                                  <option value="Active">Active</option>
                                                  <option value="InActive">InActive</option>

                                              </select>

                                          </div>
                                          
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- #END# Masked Input -->
                </div>
                <div class="modal-footer">
                    <button type="submit" name="submit" id="submit" class="btn btn-link waves-effect">SAVE DETAILS
                    </button>
                    <button type="button" class="btn btn-link waves-effect"
                            data-dismiss="modal">CLOSE
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>
