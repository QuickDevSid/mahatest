<?php
/**
 * Web Based Software Activation System
 * Developed By
 * Sagar Maher
 * Coding Visions Infotech Pvt. Ltd.
 * http://codingvisions.com/
 * 31/01/2019
 */
?>
<script type="text/javascript">
    //Tooltip
    $('[data-toggle="tooltip"]').tooltip({
        container: 'body'
    });

    $(function () {
        $('#doubts').addClass('active');
        getData();
    });

    function getData() {
//Table data featching.
        var ur = "<?php echo base_url() ?>Doubts/fetch_user";
        //Exportable table
        $('#user_data').DataTable({
            dom: 'Bfrtip',
            destroy: true,
            responsive: true,
            scrollX: true,
            scrollY: true,
            buttons: [
                'copy', 'csv', 'excel', 'pdf', 'print'
            ],
            "ajax": {
                url: ur,
                type: "POST"
            }
        });
    }

    //end code here
    function getdoughtDetails(getID) {
        var lid = getID.replace('details_', '');

        $.ajax({
            type: "GET",
            url: "<?php echo base_url() ?>Doubts_Api/doughtById/" + lid, // replace 'PHP-FILE.php with your php file
            dataType: "json",
            success: function (result) {
                $("#d_user_title").html(result[0]["username"]);
                $("#d_exam_group").html(result[0]["exam_name"]);
                $("#d_created_on").html("Posted on " + result[0]["created_on"]);
                $("#d_post_image").html('<img class="img-fluid rounded" style="width: 100%;" src="<?php echo base_url() ?>AppAPI/' + result[0]["image"] + '" alt="">');
                $("#d_question").html(result[0]["question"]);

            },
            error: function () {
                alert('Some error occurred!');
            }
        });

    }

    //code for delete user
    function showConfirmMessage(getID) {
        var lid = getID;

        swal({
            title: "Are you sure?",
            text: "Dought will be deleted with ID : " + lid + "!",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "Yes, delete it!",
            closeOnConfirm: false
        }, function () {
            deletedoughtDetailsPerform(lid);
        });
    }

    function deletedoughtDetails(getID) {
        var lid = getID.replace('delete_', '');

        showConfirmMessage(lid);
    }

    function deletedoughtDetailsPerform(getID) {
        var lid = getID;
        // alert(lid);

        if (lid === "") {
            $("#error_message").html("All Fields are Required");
            myFunctionEr();
        } else {
            $.ajax({
                type: "DELETE",
                url: "<?php echo base_url() ?>Doubts_Api/deletedought",
                data: "id=" + lid,
                success: function (data) {
                    $('#success_message').html(data);
                    console.log(data);
                    myFunctionSuc();
                    if (data === "Success") {
                        swal("Deleted!", "Dought details has been deleted.", "success");
                        getData();
                    } else {
                        $("#error_message").html(data);
                        myFunctionEr();
                    }
                }
            });
        }
    }

    function change_status(id, status)
    {
        if(id!="" && status!="")
        {
            $.ajax({
                type: "POST",
                url: "<?php echo base_url() ?>Doubts/updateStatus",
                data: "id=" + id+"&status="+status,
                success: function (data) {
                    $('#success_message').html(data);
                    console.log(data);
                    if (data === "Success") {
                        swal("Updated!", "Doubts status updated.", "success");
                        getData();
                    } else {
                        $("#error_message").html(data);
                    }
                }
            });

        }
        getData();
        return false;
    }


</script>
