<?php

$keyIdTest = 'rzp_test_7ZcXcYbLjKPgCk';
$keySecretTest = 's0mAtWPScnDUUiFe3KLrmVvr';

$keyId = 'rzp_live_tAkCvSFj3GvLFf';
$keySecret = '57tzNSww3t9biOmjOX2HvvbC';
$displayCurrency = 'INR';

//These should be commented out in production
// This is for error reporting
// Add it to config.php to report any errors
error_reporting(E_ALL);
ini_set('display_errors', 1);
