<script>
    $(document).ready(function() {

        $(function() {

            $('#courses').addClass('active');
            $('#courses .menu-toggle').addClass('toggled');
            $('#courses .ml-menu').css('display', 'block');

            $('#tests').addClass('active');
            getData();
        });


    });
</script>