<script>
    $(document).ready(function() {

        $(function() {

            $('#english_vocabulary').addClass('active');
            $('#english_vocabulary .menu-toggle').addClass('toggled');
            $('#english_vocabulary .ml-menu').css('display', 'block');

            $('#english_vocabulary_category_list').addClass('active');
            getData();
        });
    });
</script>