<script>
    $(document).ready(function() {
        $(function() {

            $('#marathi_sabd').addClass('active');
            $('#marathi_sabd .menu-toggle').addClass('toggled');
            $('#marathi_sabd .ml-menu').css('display', 'block');

            $('#marathi_sabd_category_list').addClass('active');
            getData();
        });
    });
</script>