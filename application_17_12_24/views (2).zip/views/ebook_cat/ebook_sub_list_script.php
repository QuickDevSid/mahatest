<script>
    $(document).ready(function() {



        $(function() {



            $('#ebooks_menu').addClass('active');

            $('#ebooks_menu .menu-toggle').addClass('toggled');

            $('#ebooks_menu .ml-menu').css('display', 'block');



            $('#ebooks_sub_cat_list').addClass('active');

            getData();

        });

    });
</script>