<script>
    $(document).ready(function() {

        $(function() {

            $('#news').addClass('active');
            $('#news .menu-toggle').addClass('toggled');
            $('#news .ml-menu').css('display', 'block');

            $('#news_list').addClass('active');
            getData();
        });
    });
</script>