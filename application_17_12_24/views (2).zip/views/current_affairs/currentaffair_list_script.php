<script>
    $(document).ready(function() {

        $(function() {

            $('#current_affairs').addClass('active');
            $('#current_affairs .menu-toggle').addClass('toggled');
            $('#current_affairs .ml-menu').css('display', 'block');

            $('#manage_current_affairs_form_list').addClass('active');
            getData();
        });
    });
</script>