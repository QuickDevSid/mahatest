<script>
    $(document).ready(function() {

        $(function() {

            $('#exam_material').addClass('active');
            $('#exam_material .menu-toggle').addClass('toggled');
            $('#exam_material .ml-menu').css('display', 'block');

            $('#exam_material_list').addClass('active');
            getData();
        });
    });
</script>