<script>
    $(document).ready(function() {
        $(function() {
            $('#test_series_main').addClass('active');
            $('#test_series_main .menu-toggle').addClass('toggled');
            $('#test_series_main .ml-menu').css('display', 'block');

            $('#test_series_quizs_list').addClass('active');
            getData();
        });

    });
</script>